package com.example.latlngtab;

import java.util.ArrayList;
import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class List extends Activity {
	LocationAdapter adapter;
	ListView lv;
	public static ArrayList<Location> source = new ArrayList<Location>();
	EditText txtSearch;
	TextView empty;
	LocationDatabase db;
	AlertDialog g;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.locationlist);
		db = new LocationDatabase(this);
	        if(db.getCount() > 0){      	
	        	source = db.getAllLocation();
	        }	
		this.lv = (ListView) this.findViewById(R.id.listView1);
	    this.adapter = new LocationAdapter(source,this);
	    this.lv.setAdapter(adapter); 
	   
	    adapter.notifyDataSetChanged();
	    
	}
}	
