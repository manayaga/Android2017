/** Automatically generated file. DO NOT MODIFY */
package com.example.inputoutput;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}